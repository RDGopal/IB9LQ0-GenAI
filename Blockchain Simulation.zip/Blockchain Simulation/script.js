document.addEventListener('DOMContentLoaded', () => {
    const blockchainContainer = document.getElementById('blockchain');
    const addBlockBtn = document.getElementById('addBlockBtn');
    const difficultyInput = document.getElementById('difficulty');

    let blockchain = [];
    let miningTarget = ''; // Will be set based on difficulty

    // --- Hashing Function (Async using SubtleCrypto) ---
    async function calculateHash(input) {
        const msgBuffer = new TextEncoder().encode(input);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        return hashHex;
    }

    // --- Block Creation ---
    function createBlockElement(block) {
        const blockElement = document.createElement('div');
        blockElement.classList.add('block');
        blockElement.setAttribute('data-index', block.index);

        blockElement.innerHTML = `
            <label for="block${block.index}_num">Block #:</label>
            <input type="text" id="block${block.index}_num" value="${block.index}" readonly>

            <label for="block${block.index}_nonce">Nonce:</label>
            <input type="number" class="block-nonce" id="block${block.index}_nonce" value="${block.nonce}">

            <label for="block${block.index}_data">Data:</label>
            <textarea class="block-data" id="block${block.index}_data">${block.data}</textarea>

            <label for="block${block.index}_prevhash">Previous Hash:</label>
            <input type="text" class="block-prevhash hash-input" id="block${block.index}_prevhash" value="${block.previousHash}" readonly>

            <label for="block${block.index}_hash">Hash:</label>
            <input type="text" class="block-hash hash-input" id="block${block.index}_hash" value="${block.hash}" readonly>

            <button class="mine-button">Mine Block</button>
            <div class="mining-status"></div>
        `;

        // Add event listeners for data/nonce changes
        const dataInput = blockElement.querySelector('.block-data');
        const nonceInput = blockElement.querySelector('.block-nonce');
        dataInput.addEventListener('input', () => handleBlockChange(block.index));
        nonceInput.addEventListener('input', () => handleBlockChange(block.index));

        // Add event listener for the mine button
        const mineButton = blockElement.querySelector('.mine-button');
        mineButton.addEventListener('click', () => mineBlock(block.index));

        return blockElement;
    }

    // --- Blockchain Logic ---
    function getBlockDataString(index) {
        const block = blockchain[index];
        const blockElement = document.querySelector(`.block[data-index="${index}"]`);
        const nonce = blockElement.querySelector('.block-nonce').value;
        const data = blockElement.querySelector('.block-data').value;
        const prevHash = block.previousHash; // Use the stored previous hash

        // Update block object's nonce and data for consistency
        block.nonce = parseInt(nonce) || 0; // Ensure nonce is a number
        block.data = data;

        return `${block.index}${block.nonce}${block.data}${block.previousHash}`;
    }

    async function updateBlockHash(index) {
        const block = blockchain[index];
        const blockElement = document.querySelector(`.block[data-index="${index}"]`);
        const hashInput = blockElement.querySelector('.block-hash');

        const dataString = getBlockDataString(index);
        block.hash = await calculateHash(dataString);
        hashInput.value = block.hash;
    }

    async function handleBlockChange(index) {
        await updateBlockHash(index);
        validateChain(); // Re-validate the entire chain after a change
    }

    function setDifficulty() {
        const difficulty = parseInt(difficultyInput.value) || 4;
        miningTarget = '0'.repeat(difficulty);
        console.log(`Difficulty set to ${difficulty}, target: ${miningTarget}`);
        validateChain(); // Re-validate after changing difficulty
    }

    async function mineBlock(index) {
        const block = blockchain[index];
        const blockElement = document.querySelector(`.block[data-index="${index}"]`);
        const mineButton = blockElement.querySelector('.mine-button');
        const nonceInput = blockElement.querySelector('.block-nonce');
        const hashInput = blockElement.querySelector('.block-hash');
        const statusDiv = blockElement.querySelector('.mining-status');

        mineButton.disabled = true;
        statusDiv.textContent = 'Mining...';
        nonceInput.readOnly = true; // Prevent changes during mining

        let nonce = parseInt(nonceInput.value) || 0; // Start from current nonce or 0

        console.time(`Mining Block ${index}`); // Start timer

        // Use requestAnimationFrame or setTimeout to prevent freezing
        function mineStep() {
            const dataString = `${block.index}${nonce}${block.data}${block.previousHash}`;
            calculateHash(dataString).then(hash => {
                if (hash.startsWith(miningTarget)) {
                    // Found valid nonce!
                    block.nonce = nonce;
                    block.hash = hash;
                    nonceInput.value = nonce;
                    hashInput.value = hash;

                    statusDiv.textContent = 'Mined!';
                    mineButton.disabled = false;
                    nonceInput.readOnly = false;
                    console.timeEnd(`Mining Block ${index}`); // End timer
                    console.log(`Block ${index} mined. Nonce: ${nonce}, Hash: ${hash}`);

                    // IMPORTANT: Re-validate the chain after successful mining
                    validateChain();
                } else {
                    nonce++;
                    nonceInput.value = nonce; // Update UI to show progress
                    hashInput.value = hash; // Show changing hash
                    if (nonce % 1000 === 0) { // Update status occasionally
                        statusDiv.textContent = `Mining... (Nonce: ${nonce})`;
                    }
                    // Schedule the next step
                    requestAnimationFrame(mineStep);
                     // Or use setTimeout for slower visualization: setTimeout(mineStep, 0);
                }
            }).catch(error => {
                 console.error("Hashing error during mining:", error);
                 statusDiv.textContent = 'Error during mining.';
                 mineButton.disabled = false;
                 nonceInput.readOnly = false;
            });
        }

        // Start the mining process
       requestAnimationFrame(mineStep);
    }

    function validateChain() {
        console.log("Validating chain...");
        let previousBlockHash = '0'; // Genesis block's previous hash

        for (let i = 0; i < blockchain.length; i++) {
            const block = blockchain[i];
            const blockElement = document.querySelector(`.block[data-index="${i}"]`);
            const hashInput = blockElement.querySelector('.block-hash');
            const prevHashInput = blockElement.querySelector('.block-prevhash');

            // Recalculate hash based on current data/nonce in UI for validation check
            const currentNonce = blockElement.querySelector('.block-nonce').value;
            const currentData = blockElement.querySelector('.block-data').value;
            const dataString = `${block.index}${currentNonce}${currentData}${block.previousHash}`;

            calculateHash(dataString).then(recalculatedHash => {
                 let isValid = true;
                 let isLinkBroken = false;

                 // Check 1: Does the stored previous hash match the actual previous block's hash?
                 if (block.previousHash !== previousBlockHash) {
                     isValid = false;
                     isLinkBroken = true; // The link *to* this block is broken
                     console.log(`Block ${i}: Invalid previous hash. Expected ${previousBlockHash}, got ${block.previousHash}`);
                 }

                 // Check 2: Does the recalculated hash match the difficulty target?
                 if (!recalculatedHash.startsWith(miningTarget)) {
                     isValid = false;
                     console.log(`Block ${i}: Hash ${recalculatedHash} does not meet difficulty target ${miningTarget}`);
                 }

                 // Check 3: Does the recalculated hash match the currently displayed hash? (Detects tampering)
                 // This check is implicitly covered by Check 2, but good to be aware of. If someone tampers
                 // data/nonce AFTER mining, the hash won't match the difficulty target anymore.

                // Update block object's hash if it was just calculated/validated
                // Note: We only update the hash during mining or initial calculation.
                // Here, we compare the *recalculated* hash against the target.
                hashInput.value = recalculatedHash; // Show the *current* hash based on data

                 // Apply visual styles
                 if (isValid) {
                     blockElement.classList.remove('invalid', 'link-broken');
                     blockElement.classList.add('valid');
                 } else {
                     blockElement.classList.remove('valid');
                     blockElement.classList.add('invalid');
                     if(isLinkBroken) {
                        // We add 'link-broken' to the *previous* element's perspective via CSS
                        // using the adjacent sibling combinator (+) if needed, or just mark current block
                        blockElement.classList.add('link-broken'); // Mark this block as having a broken link *to* it
                     }
                     // Invalidate all subsequent blocks visually
                     for (let j = i + 1; j < blockchain.length; j++) {
                         const subsequentBlockElement = document.querySelector(`.block[data-index="${j}"]`);
                         subsequentBlockElement.classList.remove('valid');
                         subsequentBlockElement.classList.add('invalid', 'link-broken');
                     }
                 }

                 // Update the previousBlockHash for the next iteration *using the validated hash*
                 // Only update if the block *was* valid according to its content and previous link
                 if (isValid) {
                    previousBlockHash = recalculatedHash; // Use the hash matching the content
                 } else {
                    // If the current block is invalid, break the chain validation logically
                    // Use an invalid marker or the incorrect recalculated hash to ensure subsequent blocks fail validation
                     previousBlockHash = "INVALID_CHAIN_PROPAGATION"; // Or use recalculatedHash
                 }

                 // Update the previous hash field of the *next* block visually (if it exists)
                 if (i + 1 < blockchain.length) {
                    const nextBlockElement = document.querySelector(`.block[data-index="${i + 1}"]`);
                    const nextPrevHashInput = nextBlockElement.querySelector('.block-prevhash');
                    // Update the *actual* previous hash reference in the next block object
                    blockchain[i + 1].previousHash = recalculatedHash; // Store the hash based on current content
                    nextPrevHashInput.value = blockchain[i + 1].previousHash; // Display it
                 }

            }).catch(error => {
                 console.error(`Error validating block ${i}:`, error);
                 // Mark block as invalid on error
                 blockElement.classList.remove('valid');
                 blockElement.classList.add('invalid');
            });
        }
    }


    function addBlock() {
        const previousBlock = blockchain[blockchain.length - 1];
        const newIndex = blockchain.length;
        const previousHash = previousBlock ? previousBlock.hash : '0'; // Genesis block has '0' prev hash
        const newData = `Block ${newIndex} Data`; // Default data

        const newBlock = {
            index: newIndex,
            nonce: 0,
            data: newData,
            previousHash: previousHash,
            hash: '' // Calculate initial hash below
        };

        // Calculate initial hash before adding
        const dataString = `${newBlock.index}${newBlock.nonce}${newBlock.data}${newBlock.previousHash}`;
        calculateHash(dataString).then(initialHash => {
            newBlock.hash = initialHash;
            blockchain.push(newBlock);
            const newBlockElement = createBlockElement(newBlock);
            blockchainContainer.appendChild(newBlockElement);

            // Important: Re-validate the entire chain after adding a new block
            validateChain();
        }).catch(error => console.error("Error calculating initial hash for new block:", error));
    }

    // --- Initialization ---
    function initializeBlockchain() {
        setDifficulty(); // Set initial mining target

        // Create Genesis Block
        const genesisBlock = {
            index: 0,
            nonce: 0,
            data: 'Genesis Block',
            previousHash: '0',
            hash: '' // Calculate below
        };

        const dataString = `${genesisBlock.index}${genesisBlock.nonce}${genesisBlock.data}${genesisBlock.previousHash}`;
        calculateHash(dataString).then(genesisHash => {
            genesisBlock.hash = genesisHash;
            blockchain.push(genesisBlock);
            const genesisElement = createBlockElement(genesisBlock);
            blockchainContainer.appendChild(genesisElement);
            validateChain(); // Validate initial state
        }).catch(error => console.error("Error creating genesis block hash:", error));


        addBlockBtn.addEventListener('click', addBlock);
        difficultyInput.addEventListener('change', setDifficulty);
    }

    initializeBlockchain();
});